# Classification and Ensemble Methods — Lecture Notes (Part 2)

---

# 5. GBM (Gradient Boosting Machine)

## 5.1 Boosting vs Bagging

| Aspect | Bagging (Random Forest) | Boosting (GBM) |
|---|---|---|
| Training | Parallel — trees are independent | Sequential — each tree depends on the previous |
| Goal | Reduce variance | Reduce bias |
| Base learner | Full trees (deep) | Shallow trees (stumps or depth 3–5) |
| Weighting | Equal weight for all trees | Later trees correct earlier mistakes |
| Risk | Less prone to overfitting | Can overfit if too many trees or learning rate too high |

## 5.2 Sequential Learning Idea

GBM builds trees **one at a time**. Each new tree focuses on the mistakes the ensemble made so far.

**Analogy:** Imagine you are learning to throw darts. After each throw, you look at where you missed and adjust your aim. Each subsequent throw corrects for the previous error. Over many rounds, your aim converges on the bullseye.

**Step-by-step process:**

```
1. Start with a simple prediction (e.g., the mean class probability)
2. Compute residuals = actual - predicted
3. Train a small tree to predict these residuals
4. Update predictions: new_pred = old_pred + learning_rate * tree_prediction
5. Repeat steps 2-4 for N rounds
```

## 5.3 Intuition of Residual Learning

Instead of directly predicting the target, each new tree predicts the **error (residual)** of the current ensemble.

```
Round 1: Model predicts 0.3, actual is 1.0 --> residual = 0.7
Round 2: New tree learns to predict 0.7 --> updated prediction = 0.3 + 0.1 * 0.7 = 0.37
Round 3: Residual = 0.63 --> tree predicts 0.63 --> prediction = 0.37 + 0.1 * 0.63 = 0.433
...
(predictions gradually approach 1.0)
```

The `learning_rate` (also called shrinkage) controls how much each tree contributes. Smaller values require more trees but generalize better.

> **EXAM IMPORTANT:** The learning rate is a regularization parameter. Smaller learning rate + more trees = better generalization (but slower training).

## 5.4 Hyperparameters

| Parameter | What It Controls | Guidance |
|---|---|---|
| `n_estimators` | Number of boosting rounds | 100–3000; use early stopping |
| `learning_rate` | Contribution of each tree | 0.01–0.3; smaller = more trees needed |
| `max_depth` | Depth of individual trees | 3–8 (shallow trees are standard) |
| `subsample` | Fraction of samples per tree | 0.5–0.9 (adds randomness, reduces overfitting) |
| `min_samples_leaf` | Min samples in leaf | 5–50 |

> **REAL-WORLD TIP:** Always use **early stopping** with GBM. Set `n_estimators` high (e.g., 5000) and let validation performance decide when to stop. This prevents overfitting and saves training time.

## 5.5 Example Code

```python
from sklearn.ensemble import GradientBoostingClassifier
from sklearn.datasets import load_breast_cancer
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, roc_auc_score

data = load_breast_cancer()
X_train, X_test, y_train, y_test = train_test_split(
    data.data, data.target, test_size=0.2, random_state=42
)

gbm = GradientBoostingClassifier(
    n_estimators=200,
    learning_rate=0.1,
    max_depth=4,
    subsample=0.8,
    min_samples_leaf=5,
    random_state=42
)
gbm.fit(X_train, y_train)

y_pred = gbm.predict(X_test)
y_proba = gbm.predict_proba(X_test)[:, 1]

print(f"Accuracy:  {(y_pred == y_test).mean():.4f}")
print(f"ROC-AUC:   {roc_auc_score(y_test, y_proba):.4f}")
print(classification_report(y_test, y_pred, target_names=data.target_names))
```

---

# 6. XGBoost

## 6.1 Why XGBoost is Powerful

XGBoost (eXtreme Gradient Boosting) is a production-grade implementation of gradient boosting that dominated Kaggle competitions for years. Key advantages:

- **Regularization:** L1 and L2 regularization on leaf weights prevent overfitting.
- **Sparsity-aware:** Handles missing values natively (learns default split direction).
- **Parallelism:** Parallelizes split finding within each tree (not between trees).
- **Cache optimization:** Data is stored in compressed column blocks for efficient access.
- **Built-in cross-validation:** `xgb.cv()` function.

## 6.2 Differences from GBM

| Aspect | sklearn GBM | XGBoost |
|---|---|---|
| Regularization | Limited (depth, min_samples) | L1 (`alpha`), L2 (`lambda`), `gamma` |
| Missing values | Must impute before training | Handles natively |
| Tree building | Exact greedy algorithm | Approximate + histogram methods |
| Speed | Slower | Significantly faster |
| Early stopping | Not built-in (manual) | Built-in (`early_stopping_rounds`) |
| Custom objectives | Not supported | Supported |

## 6.3 Key Parameters

| Parameter | XGBoost Name | What It Does | Typical Range |
|---|---|---|---|
| Learning rate | `eta` / `learning_rate` | Shrinkage per step | 0.01–0.3 |
| Tree depth | `max_depth` | Depth of each tree | 3–10 |
| Min child weight | `min_child_weight` | Min sum of instance weight in child | 1–10 |
| Subsample | `subsample` | Row sampling per tree | 0.5–1.0 |
| Column sampling | `colsample_bytree` | Feature sampling per tree | 0.5–1.0 |
| L2 regularization | `lambda` (`reg_lambda`) | L2 penalty on weights | 0–10 |
| L1 regularization | `alpha` (`reg_alpha`) | L1 penalty on weights | 0–10 |
| Min split loss | `gamma` | Min loss reduction for split | 0–5 |
| Scale pos weight | `scale_pos_weight` | Balances classes | ratio of neg/pos counts |

> **EXAM IMPORTANT:** The three most impactful XGBoost parameters to tune are: `learning_rate`, `max_depth`, and `n_estimators` (with early stopping).

## 6.4 Python Example

```python
import xgboost as xgb
from sklearn.datasets import load_breast_cancer
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, roc_auc_score

data = load_breast_cancer()
X_train, X_test, y_train, y_test = train_test_split(
    data.data, data.target, test_size=0.2, random_state=42
)

# Convert to DMatrix for efficiency (optional but recommended)
dtrain = xgb.DMatrix(X_train, label=y_train, feature_names=list(data.feature_names))
dtest = xgb.DMatrix(X_test, label=y_test, feature_names=list(data.feature_names))

params = {
    "objective": "binary:logistic",
    "eval_metric": "auc",
    "max_depth": 5,
    "learning_rate": 0.1,
    "subsample": 0.8,
    "colsample_bytree": 0.8,
    "reg_lambda": 1.0,
    "reg_alpha": 0.1,
    "seed": 42,
}

# Train with early stopping
model = xgb.train(
    params,
    dtrain,
    num_boost_round=500,
    evals=[(dtrain, "train"), (dtest, "eval")],
    early_stopping_rounds=30,
    verbose_eval=50
)

# Predict
y_proba = model.predict(dtest)
y_pred = (y_proba > 0.5).astype(int)

print(f"ROC-AUC: {roc_auc_score(y_test, y_proba):.4f}")
print(classification_report(y_test, y_pred, target_names=data.target_names))
```

## 6.5 Real Use Case (Breast Cancer Prediction)

The code above is a complete real use case on the Breast Cancer Wisconsin dataset:

- **30 features** (mean, standard error, worst of 10 cell nucleus measurements)
- **Binary classification:** malignant (0) vs. benign (1)
- **569 samples** — small dataset where tree-based models excel
- Typical ROC-AUC: **0.99+** with basic tuning

> **REAL-WORLD TIP:** XGBoost is the go-to model for structured/tabular data competitions and many production systems. If you only learn one model well, make it XGBoost.

---

# 7. LightGBM

## 7.1 Key Innovation (Leaf-wise Growth)

Traditional GBM (and XGBoost default) grows trees **level-wise**: all nodes at the same depth are split before moving deeper.

LightGBM grows trees **leaf-wise**: it always splits the leaf with the highest loss reduction, regardless of depth. This produces asymmetric trees that reach lower loss with fewer splits.

```
Level-wise (XGBoost default):          Leaf-wise (LightGBM):

        [root]                              [root]
       /      \                            /      \
     [A]      [B]                        [A]      [B]
    /   \    /   \                      /   \
  [C]  [D] [E]  [F]                  [C]  [D]
                                           /   \
                                         [G]   [H]
```

Additional innovations:
- **Gradient-based One-Side Sampling (GOSS):** Keeps all instances with large gradients, randomly samples those with small gradients. Focuses on the hard examples.
- **Exclusive Feature Bundling (EFB):** Bundles mutually exclusive features to reduce dimensionality. Effective for sparse data.

## 7.2 Speed vs Accuracy Tradeoff

| Aspect | LightGBM | XGBoost |
|---|---|---|
| Training speed | Faster (2-10x) | Slower |
| Memory usage | Lower | Higher |
| Accuracy on large data | Comparable or better | Comparable |
| Accuracy on small data | Can overfit more easily | More stable |
| Handling of categorical features | Native support | Requires encoding |

> **REAL-WORLD TIP:** For datasets with >100K rows, LightGBM is usually your best starting point due to speed. For small datasets (<10K rows), XGBoost tends to be more stable.

## 7.3 Hyperparameters

| Parameter | What It Does | Typical Range |
|---|---|---|
| `num_leaves` | Max leaves per tree (controls complexity) | 20–150 |
| `learning_rate` | Shrinkage | 0.01–0.3 |
| `n_estimators` | Number of boosting rounds | 100–5000 |
| `max_depth` | Limits depth (-1 = no limit) | -1 or 5–15 |
| `min_child_samples` | Min data in a leaf | 5–100 |
| `subsample` | Row sampling ratio | 0.5–1.0 |
| `colsample_bytree` | Feature sampling ratio | 0.5–1.0 |
| `reg_alpha` | L1 regularization | 0–10 |
| `reg_lambda` | L2 regularization | 0–10 |

> **EXAM IMPORTANT:** `num_leaves` is the primary complexity control in LightGBM. The relationship `num_leaves < 2^max_depth` should hold to prevent overfitting.

## 7.4 Comparison with XGBoost

| Criterion | XGBoost | LightGBM |
|---|---|---|
| Tree growth | Level-wise | Leaf-wise |
| Speed | Good | Better (2-10x) |
| Memory | Higher | Lower |
| Categorical features | Manual encoding | Native support |
| Small datasets | More robust | Can overfit |
| Community/maturity | Very mature | Mature |
| Kaggle usage | Very common | Very common |
| GPU support | Yes | Yes |

## 7.5 Example Code

```python
import lightgbm as lgb
from sklearn.datasets import load_breast_cancer
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, roc_auc_score

data = load_breast_cancer()
X_train, X_test, y_train, y_test = train_test_split(
    data.data, data.target, test_size=0.2, random_state=42
)

model = lgb.LGBMClassifier(
    n_estimators=500,
    learning_rate=0.05,
    num_leaves=31,
    max_depth=-1,
    min_child_samples=10,
    subsample=0.8,
    colsample_bytree=0.8,
    reg_alpha=0.1,
    reg_lambda=1.0,
    random_state=42,
    verbose=-1
)

model.fit(
    X_train, y_train,
    eval_set=[(X_test, y_test)],
    callbacks=[lgb.early_stopping(30), lgb.log_evaluation(50)]
)

y_pred = model.predict(X_test)
y_proba = model.predict_proba(X_test)[:, 1]

print(f"Best iteration: {model.best_iteration_}")
print(f"ROC-AUC: {roc_auc_score(y_test, y_proba):.4f}")
print(classification_report(y_test, y_pred, target_names=data.target_names))
```

---

# 8. Bayesian Optimization (HyperOpt)

## 8.1 Why Hyperparameter Tuning Matters

Model performance depends heavily on hyperparameters. The wrong `max_depth` or `learning_rate` can mean the difference between 0.85 and 0.95 ROC-AUC.

**Common tuning approaches:**

| Method | How It Works | Efficiency |
|---|---|---|
| Manual tuning | Trial and error | Low |
| Grid Search | Try all combinations | Exhaustive but slow; O(k^n) |
| Random Search | Sample random combinations | Better than grid for high dimensions |
| Bayesian Optimization | Use prior results to guide search | Most efficient |

**Analogy:** Grid search tries every restaurant in town. Random search picks random restaurants. Bayesian optimization asks friends which restaurants were good, then explores nearby options — it learns from past trials.

## 8.2 Bayesian Optimization Concept (Intuitive)

Bayesian optimization builds a **probabilistic model** (surrogate) of the objective function:

```
1. Try a few random hyperparameter configurations
2. Fit a surrogate model (e.g., Tree Parzen Estimator) to the results
3. Use the surrogate to estimate which region of hyperparameter space is most promising
4. Try the most promising configuration
5. Update the surrogate with the new result
6. Repeat steps 3-5
```

The key is the **acquisition function** — it balances:
- **Exploitation:** Try configurations near known good results
- **Exploration:** Try configurations in uncertain regions

HyperOpt uses the **Tree Parzen Estimator (TPE)** as its surrogate model.

## 8.3 HyperOpt Workflow

```python
from hyperopt import fmin, tpe, hp, STATUS_OK, Trials

# 1. Define the search space
space = {
    "max_depth": hp.choice("max_depth", range(3, 12)),
    "learning_rate": hp.loguniform("learning_rate", -5, 0),  # exp(-5) to exp(0)
    "n_estimators": hp.choice("n_estimators", range(50, 500, 50)),
    "subsample": hp.uniform("subsample", 0.5, 1.0),
    "colsample_bytree": hp.uniform("colsample_bytree", 0.5, 1.0),
}

# 2. Define the objective function (MINIMIZE this)
def objective(params):
    model = xgb.XGBClassifier(**params, random_state=42, eval_metric="logloss")
    score = cross_val_score(model, X_train, y_train, cv=3, scoring="roc_auc").mean()
    return {"loss": -score, "status": STATUS_OK}  # Negative because we minimize

# 3. Run optimization
trials = Trials()
best = fmin(fn=objective, space=space, algo=tpe.suggest,
            max_evals=50, trials=trials, rstate=np.random.default_rng(42))
```

## 8.4 Example (XGBoost Tuning)

```python
import numpy as np
import xgboost as xgb
from sklearn.datasets import load_breast_cancer
from sklearn.model_selection import train_test_split, cross_val_score
from hyperopt import fmin, tpe, hp, STATUS_OK, Trials

# Load data
data = load_breast_cancer()
X_train, X_test, y_train, y_test = train_test_split(
    data.data, data.target, test_size=0.2, random_state=42
)

# Search space
space = {
    "max_depth": hp.choice("max_depth", [3, 4, 5, 6, 7, 8]),
    "learning_rate": hp.loguniform("learning_rate", np.log(0.01), np.log(0.3)),
    "n_estimators": hp.choice("n_estimators", [100, 200, 300, 500]),
    "subsample": hp.uniform("subsample", 0.6, 1.0),
    "colsample_bytree": hp.uniform("colsample_bytree", 0.6, 1.0),
    "reg_alpha": hp.loguniform("reg_alpha", np.log(0.001), np.log(10)),
    "reg_lambda": hp.loguniform("reg_lambda", np.log(0.001), np.log(10)),
    "min_child_weight": hp.choice("min_child_weight", [1, 3, 5, 7]),
}

def objective(params):
    model = xgb.XGBClassifier(
        **params,
        objective="binary:logistic",
        eval_metric="logloss",
        random_state=42,
        use_label_encoder=False
    )
    score = cross_val_score(model, X_train, y_train, cv=5, scoring="roc_auc").mean()
    return {"loss": -score, "status": STATUS_OK}

trials = Trials()
best = fmin(
    fn=objective,
    space=space,
    algo=tpe.suggest,
    max_evals=50,
    trials=trials,
    rstate=np.random.default_rng(42)
)

print("Best hyperparameters found:")
print(best)

# Retrieve best loss
best_loss = min(t["result"]["loss"] for t in trials.trials)
print(f"Best CV ROC-AUC: {-best_loss:.4f}")
```

> **REAL-WORLD TIP:** Start with Random Search (fast, gets 90% of the way). Use Bayesian Optimization when you need to squeeze out the last 1-2% of performance and have the compute budget.
