# Classification and Ensemble Methods — Lecture Notes

---

# 1. Classification Overview

## What Is Classification?

Classification is the task of assigning a **discrete label** to an input based on its features. A model learns a decision boundary from labeled training data, then uses that boundary to predict the class of unseen observations.

**Analogy:** A doctor classifying a patient's condition as "diabetic" or "non-diabetic" based on blood test results. The doctor has seen many patients (training data) and uses learned patterns to decide.

### Difference from Regression

| Aspect | Classification | Regression |
|---|---|---|
| Output | Discrete label (cat, dog, spam) | Continuous value (price, temperature) |
| Loss function | Cross-entropy, Gini, misclassification | MSE, MAE |
| Evaluation | Accuracy, F1, ROC-AUC | RMSE, R-squared |
| Example | Will this customer churn? (yes/no) | How much will this customer spend? ($) |

### Real-World Examples

- Email spam detection (spam vs. not spam)
- Medical diagnosis (malignant vs. benign tumor)
- Credit card fraud detection (fraud vs. legitimate)
- Sentiment analysis (positive vs. negative review)
- Handwritten digit recognition (0-9)

## Key Evaluation Metrics

> **EXAM IMPORTANT:** You must know the difference between Precision and Recall, and when each matters more.

### Accuracy

```
Accuracy = (TP + TN) / (TP + TN + FP + FN)
```

- Proportion of all correct predictions.
- **When it fails:** Imbalanced datasets. If 99% of emails are not spam, a model that always predicts "not spam" gets 99% accuracy but catches zero spam.

### Precision

```
Precision = TP / (TP + FP)
```

- Of all instances the model labeled positive, how many were actually positive?
- **Use when:** False positives are costly. Example: recommending surgery — you want to be sure.

### Recall (Sensitivity)

```
Recall = TP / (TP + FN)
```

- Of all actual positive instances, how many did the model catch?
- **Use when:** False negatives are costly. Example: cancer screening — missing a case is dangerous.

### F1 Score

```
F1 = 2 * (Precision * Recall) / (Precision + Recall)
```

- Harmonic mean of Precision and Recall. Balances the two.
- Prefer F1 when you care about both false positives and false negatives.

### ROC-AUC

- ROC curve plots True Positive Rate (Recall) vs. False Positive Rate at various thresholds.
- AUC = Area Under the ROC Curve. Ranges from 0.5 (random) to 1.0 (perfect).
- **Use when:** You want a threshold-independent measure of model quality.

> **REAL-WORLD TIP:** In production, choose your metric BEFORE training. The metric drives every downstream decision — model architecture, threshold tuning, and feature engineering.

### Confusion Matrix Sketch

```
                 Predicted
              Positive  Negative
Actual  Pos  [  TP    |   FN   ]
        Neg  [  FP    |   TN   ]
```

---

# 2. Decision Tree

## 2.1 Core Idea

A Decision Tree recursively splits data into subsets by asking yes/no questions about features. Each internal node is a question, each branch is an answer, and each leaf is a prediction.

**Analogy:** Playing the game "20 Questions." You ask the most informative question first to narrow down the answer as fast as possible.

```
                  [Age > 30?]
                 /            \
              Yes              No
         [Income > 50K?]    [Student?]
         /         \         /       \
       Yes         No      Yes       No
     Buy:Yes    Buy:No   Buy:Yes   Buy:No
```

## 2.2 How Splitting Works

At each node, the algorithm evaluates every possible split on every feature and chooses the one that best separates the classes.

### Gini Impurity

```
Gini(S) = 1 - sum(p_i^2)  for each class i
```

- Measures the probability of misclassifying a randomly chosen element.
- Gini = 0 means the node is pure (all one class).
- Gini = 0.5 means maximum impurity for binary classification (50/50 split).

### Information Gain (Entropy)

```
Entropy(S) = -sum(p_i * log2(p_i))

Information Gain = Entropy(parent) - weighted_avg(Entropy(children))
```

- Measures the reduction in uncertainty after a split.
- Higher information gain = better split.

> **EXAM IMPORTANT:** Gini is the default in scikit-learn's `DecisionTreeClassifier`. Entropy is slightly more computationally expensive but often produces similar results. Know both formulas.

**Gini vs. Entropy comparison:**

| Criterion | Range | Speed | Notes |
|---|---|---|---|
| Gini | [0, 0.5] for binary | Faster | Default in sklearn |
| Entropy | [0, 1.0] for binary | Slower | More theoretically grounded |

In practice, they rarely produce significantly different trees.

## 2.3 Key Parameters

| Parameter | What It Controls | Typical Values |
|---|---|---|
| `max_depth` | Maximum tree depth | 3–20, or None |
| `min_samples_split` | Min samples to split a node | 2–20 |
| `min_samples_leaf` | Min samples in a leaf node | 1–10 |
| `max_features` | Features considered per split | "sqrt", "log2", None |
| `criterion` | Splitting criterion | "gini", "entropy" |

## 2.4 Visualization Concept

A trained Decision Tree can be visualized as a flowchart. Each box shows:
- The splitting condition (e.g., `petal_length <= 2.45`)
- The Gini value at that node
- The number of samples reaching that node
- The class distribution

This is one of the biggest advantages of decision trees: **interpretability**. You can explain every prediction to a non-technical stakeholder.

## 2.5 Overfitting Problem

Decision Trees are prone to overfitting because they can grow until each leaf has a single sample — perfectly memorizing the training data but failing on new data.

**Signs of overfitting:**
- Very deep tree
- Training accuracy much higher than validation accuracy
- Complex decision boundaries that capture noise

**Solutions:**
- Pruning: set `max_depth`, `min_samples_leaf`, `min_samples_split`
- Use ensemble methods (Random Forest, Gradient Boosting)

## 2.6 Practical Example

```python
import numpy as np
import pandas as pd
from sklearn.datasets import make_classification
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier, export_text
from sklearn.metrics import classification_report, accuracy_score

# --- Generate a synthetic user behavior dataset ---
X, y = make_classification(
    n_samples=1000, n_features=5, n_informative=3,
    n_redundant=1, n_classes=2, random_state=42
)
feature_names = ["page_views", "session_duration", "bounce_rate",
                 "pages_per_session", "returning_visitor"]
X = pd.DataFrame(X, columns=feature_names)

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

# --- Train a Decision Tree ---
dt = DecisionTreeClassifier(
    max_depth=4,
    min_samples_leaf=5,
    criterion="gini",
    random_state=42
)
dt.fit(X_train, y_train)

# --- Evaluate ---
y_pred = dt.predict(X_test)
print("Accuracy:", accuracy_score(y_test, y_pred))
print(classification_report(y_test, y_pred))

# --- Print tree rules ---
print(export_text(dt, feature_names=feature_names))
```

> **REAL-WORLD TIP:** Always constrain your decision tree. An unconstrained tree on real data almost always overfits. Start with `max_depth=5` and tune from there.

---

# 3. Ensemble Learning

## 3.1 Why Ensemble Works (Bias-Variance Intuition)

**Core insight:** A single model has weaknesses. Combining multiple models can cancel out individual errors.

**Analogy:** If you ask one person to estimate the number of jelly beans in a jar, they might be way off. But if you ask 100 people and average their answers, the average is usually very close to the true number. This is the "wisdom of crowds."

### Bias-Variance Decomposition

```
Total Error = Bias^2 + Variance + Irreducible Noise
```

- **High Bias:** Model is too simple, underfits (e.g., single stump).
- **High Variance:** Model is too complex, overfits (e.g., deep tree that memorizes noise).

| Strategy | What It Reduces | How |
|---|---|---|
| Bagging | Variance | Train many models on bootstrap samples, average predictions |
| Boosting | Bias | Train models sequentially, each correcting the previous error |

> **EXAM IMPORTANT:** Bagging reduces variance. Boosting reduces bias. This is a fundamental distinction.

## 3.2 Voting Methods

### Hard Voting

Each classifier in the ensemble votes for a class. The class with the most votes wins.

```
Model A predicts: Cat
Model B predicts: Dog
Model C predicts: Cat
--> Hard vote result: Cat (2 vs 1)
```

### Soft Voting

Each classifier outputs class probabilities. These probabilities are averaged, and the class with the highest average probability wins.

```
Model A: Cat=0.7, Dog=0.3
Model B: Cat=0.4, Dog=0.6
Model C: Cat=0.8, Dog=0.2
Average: Cat=0.633, Dog=0.367
--> Soft vote result: Cat
```

**Soft voting is generally better** because it accounts for model confidence, not just the final label.

## 3.3 Voting Classifier Example

```python
from sklearn.ensemble import VotingClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.svm import SVC
from sklearn.datasets import make_classification
from sklearn.model_selection import cross_val_score

X, y = make_classification(n_samples=1000, n_features=10,
                           n_informative=5, random_state=42)

# Define individual classifiers
lr = LogisticRegression(max_iter=1000, random_state=42)
dt = DecisionTreeClassifier(max_depth=5, random_state=42)
svc = SVC(probability=True, random_state=42)  # probability=True for soft voting

# Hard Voting
hard_vote = VotingClassifier(
    estimators=[("lr", lr), ("dt", dt), ("svc", svc)],
    voting="hard"
)

# Soft Voting
soft_vote = VotingClassifier(
    estimators=[("lr", lr), ("dt", dt), ("svc", svc)],
    voting="soft"
)

# Compare
for name, model in [("Logistic Regression", lr),
                     ("Decision Tree", dt),
                     ("SVC", svc),
                     ("Hard Voting", hard_vote),
                     ("Soft Voting", soft_vote)]:
    scores = cross_val_score(model, X, y, cv=5, scoring="accuracy")
    print(f"{name:25s} | Accuracy: {scores.mean():.4f} (+/- {scores.std():.4f})")
```

---

# 4. Random Forest

## 4.1 Concept (Bagging + Randomness)

Random Forest = many Decision Trees trained with two sources of randomness:

1. **Bootstrap Sampling (Bagging):** Each tree is trained on a random sample (with replacement) of the training data. Roughly 63% of the data appears in each bootstrap sample.
2. **Random Feature Selection:** At each split, only a random subset of features is considered (typically `sqrt(n_features)` for classification).

**Analogy:** Instead of asking one expert who might be biased, you ask many experts who each received a slightly different subset of information. Their combined opinion is more robust.

## 4.2 Why It Reduces Overfitting

- Individual trees overfit to their bootstrap sample.
- But each tree overfits **differently** because of the randomness.
- When you average their predictions, the individual overfitting noise cancels out.
- The result: lower variance with roughly the same bias.

**Mathematical intuition:** If trees make independent errors with variance sigma-squared, averaging N trees gives variance sigma-squared / N.

> **EXAM IMPORTANT:** The key to Random Forest is **decorrelation** of trees. Random feature selection forces trees to learn different patterns, making their errors less correlated.

## 4.3 Key Hyperparameters

| Parameter | What It Controls | Recommended Starting Value |
|---|---|---|
| `n_estimators` | Number of trees | 100–500 |
| `max_depth` | Maximum depth of each tree | None (grow fully) or 10–30 |
| `max_features` | Features per split | "sqrt" (classification) |
| `min_samples_leaf` | Minimum samples per leaf | 1–5 |
| `n_jobs` | Parallel training | -1 (all cores) |
| `oob_score` | Use out-of-bag samples for validation | True |

> **REAL-WORLD TIP:** Out-of-bag (OOB) score is a free validation estimate. Each sample is predicted only by trees that did NOT include it in their bootstrap sample. It is roughly equivalent to cross-validation but costs nothing extra.

## 4.4 Practical Code Example

```python
from sklearn.ensemble import RandomForestClassifier
from sklearn.datasets import load_breast_cancer
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, roc_auc_score
import numpy as np

# Load data
data = load_breast_cancer()
X_train, X_test, y_train, y_test = train_test_split(
    data.data, data.target, test_size=0.2, random_state=42
)

# Train Random Forest
rf = RandomForestClassifier(
    n_estimators=200,
    max_depth=None,
    max_features="sqrt",
    min_samples_leaf=2,
    oob_score=True,
    n_jobs=-1,
    random_state=42
)
rf.fit(X_train, y_train)

# Evaluate
y_pred = rf.predict(X_test)
y_proba = rf.predict_proba(X_test)[:, 1]

print(f"OOB Score:  {rf.oob_score_:.4f}")
print(f"Test Acc:   {(y_pred == y_test).mean():.4f}")
print(f"ROC-AUC:    {roc_auc_score(y_test, y_proba):.4f}")
print(classification_report(y_test, y_pred,
      target_names=data.target_names))

# Feature importance
importances = rf.feature_importances_
indices = np.argsort(importances)[::-1]
print("\nTop 10 features:")
for i in range(10):
    print(f"  {data.feature_names[indices[i]]:30s} {importances[indices[i]]:.4f}")
```

## 4.5 When It Fails

- **Very high-dimensional sparse data** (e.g., text with TF-IDF): Linear models often outperform.
- **When features are highly correlated:** The "random feature" trick provides less decorrelation, so trees become similar.
- **When interpretability is required:** A forest of 200 trees is hard to explain. Use a single tree or SHAP values.
- **Real-time low-latency prediction:** Inference through 200+ trees can be slow for sub-millisecond requirements.
- **Small datasets:** With few samples, bootstrap sampling produces very overlapping subsets.

> **REAL-WORLD TIP:** Random Forest is an excellent **baseline** model. When approaching any tabular classification problem, train a Random Forest first. It requires minimal tuning and gives you a performance floor.
