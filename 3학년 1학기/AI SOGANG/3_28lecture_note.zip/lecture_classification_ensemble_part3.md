# Classification and Ensemble Methods — Lecture Notes (Part 3)

---

# 9. Practical Project 1: Santander Customer Satisfaction

## 9.1 Data Preprocessing Steps

The Santander Customer Satisfaction dataset is a classic Kaggle competition dataset with:
- ~76,000 training samples, ~76,000 test samples
- 370 anonymized features
- Binary target: 1 = dissatisfied, 0 = satisfied
- Highly imbalanced (~4% positive class)

**Preprocessing pipeline:**

```python
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split

# Load data
train = pd.read_csv("train.csv")
X = train.drop(["ID", "TARGET"], axis=1)
y = train["TARGET"]

# Step 1: Remove constant features (zero variance)
constant_cols = [col for col in X.columns if X[col].nunique() <= 1]
X = X.drop(constant_cols, axis=1)
print(f"Removed {len(constant_cols)} constant features")

# Step 2: Remove duplicate features
duplicate_cols = []
seen = set()
for col in X.columns:
    col_hash = tuple(X[col].values)
    if col_hash in seen:
        duplicate_cols.append(col)
    else:
        seen.add(col_hash)
X = X.drop(duplicate_cols, axis=1)
print(f"Removed {len(duplicate_cols)} duplicate features")

# Step 3: Remove highly correlated features (>0.95)
corr_matrix = X.corr().abs()
upper = corr_matrix.where(np.triu(np.ones(corr_matrix.shape), k=1).astype(bool))
high_corr_cols = [col for col in upper.columns if any(upper[col] > 0.95)]
X = X.drop(high_corr_cols, axis=1)
print(f"Removed {len(high_corr_cols)} highly correlated features")
print(f"Final feature count: {X.shape[1]}")

X_train, X_val, y_train, y_val = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y
)
```

## 9.2 Model Training (XGBoost / LightGBM)

```python
import xgboost as xgb
from sklearn.metrics import roc_auc_score

dtrain = xgb.DMatrix(X_train, label=y_train)
dval = xgb.DMatrix(X_val, label=y_val)

params = {
    "objective": "binary:logistic",
    "eval_metric": "auc",
    "max_depth": 5,
    "learning_rate": 0.02,
    "subsample": 0.7,
    "colsample_bytree": 0.7,
    "scale_pos_weight": (y_train == 0).sum() / (y_train == 1).sum(),
    "reg_lambda": 2.0,
    "reg_alpha": 0.5,
    "seed": 42,
}

model = xgb.train(
    params, dtrain,
    num_boost_round=2000,
    evals=[(dtrain, "train"), (dval, "val")],
    early_stopping_rounds=50,
    verbose_eval=100
)

y_proba = model.predict(dval)
print(f"Validation ROC-AUC: {roc_auc_score(y_val, y_proba):.4f}")
```

## 9.3 Tuning Strategy

1. **Coarse search:** Fix `learning_rate=0.1`, tune `max_depth` (3–8) and `n_estimators`
2. **Row/column sampling:** Tune `subsample` and `colsample_bytree` (0.5–0.9)
3. **Regularization:** Tune `reg_alpha` and `reg_lambda`
4. **Fine-tune learning rate:** Reduce to 0.01–0.05, increase `n_estimators` with early stopping

## 9.4 Evaluation

```python
from sklearn.metrics import roc_auc_score, precision_recall_curve, auc

y_proba = model.predict(dval)

# ROC-AUC
roc_auc = roc_auc_score(y_val, y_proba)

# Precision-Recall AUC (better for imbalanced data)
precision, recall, _ = precision_recall_curve(y_val, y_proba)
pr_auc = auc(recall, precision)

print(f"ROC-AUC:    {roc_auc:.4f}")
print(f"PR-AUC:     {pr_auc:.4f}")
```

> **REAL-WORLD TIP:** For imbalanced datasets, ROC-AUC can be overly optimistic. Always check Precision-Recall AUC alongside it. Use `scale_pos_weight` in XGBoost to handle imbalance.

---

# 10. Practical Project 2: Credit Card Fraud Detection

## 10.1 Class Imbalance Problem

Credit card fraud datasets are extremely imbalanced — typically 0.1–0.5% of transactions are fraudulent.

**Why this is a problem:**
- Models learn to predict "not fraud" for everything and get 99.9% accuracy
- Standard metrics like accuracy are misleading
- The model never learns the decision boundary for the minority class

**Analogy:** Imagine learning to identify a rare bird species by looking at 10,000 photos of pigeons and 5 photos of the rare bird. You would barely learn what the rare bird looks like.

## 10.2 Sampling Techniques

### Undersampling

Remove samples from the majority class to balance the dataset.

```python
from sklearn.utils import resample

# Separate majority and minority classes
df_majority = df[df["Class"] == 0]
df_minority = df[df["Class"] == 1]

# Undersample majority class
df_majority_under = resample(
    df_majority,
    replace=False,
    n_samples=len(df_minority),
    random_state=42
)

df_balanced = pd.concat([df_majority_under, df_minority])
```

- **Pros:** Fast, simple
- **Cons:** Throws away valuable data from the majority class

### Oversampling

Duplicate samples from the minority class (with replacement).

```python
df_minority_over = resample(
    df_minority,
    replace=True,
    n_samples=len(df_majority),
    random_state=42
)

df_balanced = pd.concat([df_majority, df_minority_over])
```

- **Pros:** No data loss
- **Cons:** Duplicates can lead to overfitting

### SMOTE (Synthetic Minority Over-sampling Technique)

Generates **synthetic** minority samples by interpolating between existing minority samples and their k-nearest neighbors.

```python
from imblearn.over_sampling import SMOTE

smote = SMOTE(random_state=42)
X_resampled, y_resampled = smote.fit_resample(X_train, y_train)

print(f"Before SMOTE: {dict(zip(*np.unique(y_train, return_counts=True)))}")
print(f"After SMOTE:  {dict(zip(*np.unique(y_resampled, return_counts=True)))}")
```

> **EXAM IMPORTANT:** SMOTE must be applied ONLY to training data, NEVER to test/validation data. Apply it inside a cross-validation loop, not before.

## 10.3 Pipeline Comparison

```python
from sklearn.model_selection import StratifiedKFold, cross_val_score
from sklearn.ensemble import RandomForestClassifier
from sklearn.pipeline import Pipeline
from imblearn.pipeline import Pipeline as ImbPipeline
from imblearn.over_sampling import SMOTE
from sklearn.preprocessing import StandardScaler
import numpy as np

# Assume X, y are loaded from the credit card dataset

clf = RandomForestClassifier(n_estimators=100, random_state=42, n_jobs=-1)
skf = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)

# --- Pipeline 1: Original data (no resampling) ---
pipe_original = Pipeline([
    ("scaler", StandardScaler()),
    ("clf", clf)
])

scores_original = cross_val_score(
    pipe_original, X, y, cv=skf, scoring="f1"
)

# --- Pipeline 2: With SMOTE ---
pipe_smote = ImbPipeline([
    ("scaler", StandardScaler()),
    ("smote", SMOTE(random_state=42)),
    ("clf", clf)
])

scores_smote = cross_val_score(
    pipe_smote, X, y, cv=skf, scoring="f1"
)

# --- Pipeline 3: With outlier removal + SMOTE ---
from sklearn.ensemble import IsolationForest

# Remove outliers from majority class first
iso = IsolationForest(contamination=0.01, random_state=42)
outlier_mask = iso.fit_predict(X) != -1
X_clean, y_clean = X[outlier_mask], y[outlier_mask]

pipe_clean_smote = ImbPipeline([
    ("scaler", StandardScaler()),
    ("smote", SMOTE(random_state=42)),
    ("clf", clf)
])

scores_clean = cross_val_score(
    pipe_clean_smote, X_clean, y_clean, cv=skf, scoring="f1"
)

print(f"Original data    | F1: {scores_original.mean():.4f} (+/- {scores_original.std():.4f})")
print(f"SMOTE            | F1: {scores_smote.mean():.4f} (+/- {scores_smote.std():.4f})")
print(f"Outlier + SMOTE  | F1: {scores_clean.mean():.4f} (+/- {scores_clean.std():.4f})")
```

## 10.4 Evaluation Strategy

For fraud detection, the right evaluation strategy is critical:

| Metric | Why It Matters Here |
|---|---|
| **Recall** | Most important — missing a fraud is very costly |
| **Precision** | Matters for reducing false alarms (annoying customers) |
| **F1 Score** | Balance between recall and precision |
| **PR-AUC** | Threshold-independent metric, better than ROC-AUC for imbalanced data |

```python
from sklearn.metrics import (classification_report, precision_recall_curve,
                              roc_auc_score, auc, confusion_matrix)

y_pred = model.predict(X_test)
y_proba = model.predict_proba(X_test)[:, 1]

print(confusion_matrix(y_test, y_pred))
print(classification_report(y_test, y_pred, target_names=["Legit", "Fraud"]))
print(f"ROC-AUC: {roc_auc_score(y_test, y_proba):.4f}")

precision, recall, thresholds = precision_recall_curve(y_test, y_proba)
print(f"PR-AUC:  {auc(recall, precision):.4f}")
```

> **REAL-WORLD TIP:** In fraud detection, you can adjust the classification threshold. Lowering it from 0.5 to 0.3 catches more fraud (higher recall) at the cost of more false alarms (lower precision). The business decides the right tradeoff.

---

# 11. Stacking Ensemble

## 11.1 Core Idea

Stacking trains a **meta-learner** on top of base model predictions. Instead of simple voting, a second model learns the optimal way to combine base model outputs.

**Analogy:** Instead of asking three friends and taking a majority vote, you hire a manager who has observed how accurate each friend is in different situations and knows when to trust each one.

```
Layer 1 (Base Models):

  Input --> [Model A] --> pred_A
  Input --> [Model B] --> pred_B
  Input --> [Model C] --> pred_C

Layer 2 (Meta-Learner):

  [pred_A, pred_B, pred_C] --> [Meta-Model] --> Final Prediction
```

## 11.2 Basic Stacking

In the simplest form:
1. Train base models on training data
2. Generate predictions on the training data
3. Use those predictions as features for the meta-learner

**Problem:** Base models see their own training data, so their training predictions are overfit. The meta-learner learns from overfit predictions.

## 11.3 CV-based Stacking

The solution is **cross-validated stacking** (also called out-of-fold predictions):

```
For each fold k in K-fold CV:
  1. Train base models on all folds EXCEPT fold k
  2. Generate predictions on fold k (out-of-fold predictions)
  3. These predictions have NOT been seen during training

Stack all out-of-fold predictions to form the meta-features
Train the meta-learner on these meta-features
```

This prevents information leakage and gives the meta-learner honest predictions to learn from.

> **EXAM IMPORTANT:** Always use CV-based stacking, not basic stacking. Basic stacking causes information leakage and produces overly optimistic results.

## 11.4 Code Example

```python
from sklearn.ensemble import (StackingClassifier, RandomForestClassifier,
                               GradientBoostingClassifier)
from sklearn.linear_model import LogisticRegression
from sklearn.svm import SVC
from sklearn.datasets import load_breast_cancer
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.metrics import roc_auc_score

data = load_breast_cancer()
X_train, X_test, y_train, y_test = train_test_split(
    data.data, data.target, test_size=0.2, random_state=42
)

# Define base learners
base_learners = [
    ("rf", RandomForestClassifier(n_estimators=100, random_state=42)),
    ("gbm", GradientBoostingClassifier(n_estimators=100, random_state=42)),
    ("svc", SVC(probability=True, random_state=42)),
]

# Define meta-learner
meta_learner = LogisticRegression(max_iter=1000, random_state=42)

# Stacking Classifier (uses CV-based stacking internally)
stacking_clf = StackingClassifier(
    estimators=base_learners,
    final_estimator=meta_learner,
    cv=5,                   # 5-fold CV for generating meta-features
    stack_method="predict_proba",  # Use probabilities, not hard labels
    n_jobs=-1
)

stacking_clf.fit(X_train, y_train)

# Evaluate
y_pred = stacking_clf.predict(X_test)
y_proba = stacking_clf.predict_proba(X_test)[:, 1]

print(f"Stacking Accuracy: {(y_pred == y_test).mean():.4f}")
print(f"Stacking ROC-AUC:  {roc_auc_score(y_test, y_proba):.4f}")

# Compare with individual models
for name, model in base_learners:
    scores = cross_val_score(model, X_train, y_train, cv=5, scoring="roc_auc")
    print(f"{name:5s} CV ROC-AUC: {scores.mean():.4f}")
```

> **REAL-WORLD TIP:** For the meta-learner, use a simple model (LogisticRegression or Ridge). A complex meta-learner can overfit to the base model predictions. The meta-learner's job is to learn weights, not complex patterns.

---

# 12. Final Summary

## When to Use Each Model

| Situation | Recommended Model | Why |
|---|---|---|
| Quick baseline on tabular data | Random Forest | Minimal tuning, robust out of the box |
| Small dataset (<10K rows) | XGBoost | More stable regularization |
| Large dataset (>100K rows) | LightGBM | Speed advantage with comparable accuracy |
| Need interpretability | Decision Tree | Human-readable rules |
| Maximum accuracy on tabular data | Stacking (XGBoost + LightGBM + RF) | Combines diverse learners |
| Kaggle competition | XGBoost or LightGBM with hyperopt tuning | Proven competition track record |
| Imbalanced dataset | XGBoost/LightGBM + SMOTE | scale_pos_weight + sampling |

## Comparison Table

| Feature | Decision Tree | Random Forest | GBM | XGBoost | LightGBM |
|---|---|---|---|---|---|
| Bias | High (if shallow) | Low | Low | Low | Low |
| Variance | High | Low | Medium-Low | Medium-Low | Medium-Low |
| Speed (train) | Fast | Medium | Slow | Fast | Fastest |
| Speed (predict) | Fast | Medium | Medium | Fast | Fast |
| Overfitting risk | High | Low | Medium | Low (regularized) | Medium |
| Interpretability | High | Low | Low | Low | Low |
| Missing values | Needs imputation | Needs imputation | Needs imputation | Native handling | Native handling |
| Categorical features | Needs encoding | Needs encoding | Needs encoding | Needs encoding | Native support |
| Parallelism | N/A | Yes (trees) | No (sequential) | Within-tree | Within-tree |

## Common Mistakes Students Make

> **EXAM IMPORTANT:** Avoid these common pitfalls.

1. **Data leakage in preprocessing:** Applying SMOTE or scaling before train/test split. Always split first, then preprocess training data only.

2. **Using accuracy for imbalanced datasets:** A 99% accuracy can mean zero recall on the minority class. Use F1, PR-AUC, or ROC-AUC instead.

3. **Not using early stopping with boosting:** Setting `n_estimators=1000` without early stopping almost always overfits.

4. **Tuning too many parameters at once:** Start with the most impactful parameters (`learning_rate`, `max_depth`, `n_estimators`) before tuning regularization.

5. **Forgetting to set `random_state`:** Results become non-reproducible, making debugging impossible.

6. **Applying the same model to every problem:** Text data and image data need different architectures. Tree models excel on **tabular** data.

7. **Ignoring feature engineering:** No amount of hyperparameter tuning compensates for poor features. Spend 60% of your time on features.

8. **Confusing Gini with Information Gain:** Gini measures impurity directly. Information Gain measures the reduction in entropy. Both lead to similar trees in practice but you must know the formulas.

9. **Not looking at the confusion matrix:** Aggregate metrics hide important details. Always examine per-class performance.

10. **Over-engineering the meta-learner in stacking:** Use LogisticRegression, not another GBM. The meta-learner should be simple.

---

## Quick Reference: Model Selection Flowchart

```
Start
  |
  v
Is the data tabular? --No--> Consider neural networks, NLP/CV models
  |
  Yes
  v
How much data? 
  |
  < 10K --> XGBoost (most stable)
  10K-100K --> XGBoost or LightGBM
  > 100K --> LightGBM (fastest)
  |
  v
Need interpretability? --Yes--> Single Decision Tree (with max_depth)
  |
  No
  v
Need maximum accuracy? --Yes--> Stacking: XGB + LGBM + RF with meta-learner
  |
  No
  v
Random Forest (reliable baseline, minimal tuning)
```

---

**End of Lecture Notes**
