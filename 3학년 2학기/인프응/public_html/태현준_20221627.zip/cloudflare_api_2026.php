<?php
// 설정
$CLOUDFLARE_ACCOUNT_ID = 'b89f7add8a2fb07540526744fea93917';
$CLOUDFLARE_API_TOKEN = 'cfut_oQITJfcFU2jr7HguqgUWfYyzeXwF6VTVOMd0KSUr0092f673';

ini_set('display_errors', '0');
if (function_exists('set_time_limit')) @set_time_limit(160);
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
header('X-Content-Type-Options: nosniff');

$models = [
    'text-classification' => ['@cf/huggingface/distilbert-sst-2-int8'],
    'text-generation' => ['@cf/meta/llama-3.2-3b-instruct', 
	'@cf/meta/llama-3.2-1b-instruct', 
    '@cf/meta/llama-3.1-8b-instruct-fp8-fast',
    '@cf/qwen/qwen3.8-27b'],
    'image-analysis' => ['@cf/meta/llama-3.2-11b-vision-instruct'],
    'image-classification' => ['@cf/microsoft/resnet-50'],
    'text-to-image' => ['@cf/black-forest-labs/flux-1-schnell']
];
$rawResponse = null;

// 공통 응답
function respond($data, $status = 200)
{
    global $rawResponse, $CLOUDFLARE_ACCOUNT_ID, $CLOUDFLARE_API_TOKEN;
    if ($rawResponse !== null) $data['raw_response'] = $rawResponse;
    $secrets = [trim($CLOUDFLARE_ACCOUNT_ID), trim($CLOUDFLARE_API_TOKEN)];
    array_walk_recursive($data, function (&$value) use ($secrets) {
        if (!is_string($value)) return;
        foreach ($secrets as $secret) {
            if ($secret !== '') $value = str_replace($secret, '[REDACTED]', $value);
        }
    });
    http_response_code($status);
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE);
    exit;
}

function fail($message, $status = 400)
{
    respond(['ok' => false, 'message' => $message], $status);
}

function field($name, $default = '')
{
    $value = $_POST[$name] ?? $default;
    if (!is_string($value)) fail($name . ' 값이 잘못되었습니다.');
    return trim($value);
}

// Cloudflare 호출
function cloudflare($model, $payload, $mime = 'application/json')
{
    global $CLOUDFLARE_ACCOUNT_ID, $CLOUDFLARE_API_TOKEN, $rawResponse;
    $account = trim($CLOUDFLARE_ACCOUNT_ID);
    $token = trim($CLOUDFLARE_API_TOKEN);
    if (!preg_match('/^[a-fA-F0-9]{32}$/D', $account) || !$token || strpos($token, 'YOUR_') === 0 || preg_match('/\s/', $token)) {
        fail('PHP 상단의 Account ID와 API 토큰을 입력해 주세요.', 500);
    }
    if (!function_exists('curl_init')) fail('서버에서 PHP cURL을 활성화해 주세요.', 500);
    $body = $mime === 'application/json' ? json_encode($payload, JSON_UNESCAPED_UNICODE) : $payload;
    if ($body === false) fail('입력 내용을 UTF-8로 확인해 주세요.');
    $curl = curl_init('https://api.cloudflare.com/client/v4/accounts/' . $account . '/ai/run/' . $model);
    curl_setopt_array($curl, [
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => $body,
        CURLOPT_HTTPHEADER => ['Authorization: Bearer ' . $token, 'Content-Type: ' . $mime, 'Accept: application/json'],
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_CONNECTTIMEOUT => 10,
        CURLOPT_TIMEOUT => 120,
        CURLOPT_FOLLOWLOCATION => false,
        CURLOPT_SSL_VERIFYPEER => true,
        CURLOPT_SSL_VERIFYHOST => 2
    ]);
    $raw = curl_exec($curl);
    $status = (int) curl_getinfo($curl, CURLINFO_HTTP_CODE);
    $errno = curl_errno($curl);
    curl_close($curl);
    if ($raw === false) fail('Cloudflare 연결에 실패했거나 응답 시간이 초과되었습니다.', $errno === 28 ? 504 : 502);
    $data = json_decode($raw, true);
    if (!is_array($data)) fail('Cloudflare에서 올바른 JSON 응답을 받지 못했습니다.', 502);
    $rawResponse = $data;
    if ($status < 200 || $status >= 300 || ($data['success'] ?? true) === false || !empty($data['errors']) || isset($data['error'])) {
        $error = $data['errors'][0] ?? ($data['error'] ?? '요청을 처리하지 못했습니다.');
        $message = is_array($error) ? ($error['message'] ?? '') : $error;
        if (!is_string($message) || $message === '') $message = '요청을 처리하지 못했습니다.';
        fail('Cloudflare: ' . $message, $status >= 400 && $status <= 599 ? $status : 502);
    }
    return $data['result'] ?? $data;
}

// 이미지 업로드
function uploadedImage()
{
    $file = $_FILES['image'] ?? [];
    if (($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) fail('이미지를 선택해 주세요. 업로드 제한을 넘었다면 크기를 줄여 주세요.');
    $path = $file['tmp_name'] ?? '';
    if (!is_string($path) || !is_uploaded_file($path)) fail('잘못된 이미지 업로드입니다.');
    if (filesize($path) > 2097152) fail('이미지는 2MB 이하여야 합니다.', 413);
    $info = @getimagesize($path);
    $mime = $info['mime'] ?? '';
    if (!in_array($mime, ['image/jpeg', 'image/png', 'image/webp'], true)) fail('JPEG, PNG, WEBP 이미지만 사용할 수 있습니다.', 415);
    if ($info[0] > 8192 || $info[1] > 8192 || $info[0] * $info[1] > 16000000) fail('이미지 해상도를 줄여 주세요.', 413);
    $bytes = file_get_contents($path);
    if ($bytes === false) fail('이미지를 읽지 못했습니다.', 500);
    return ['bytes' => $bytes, 'mime' => $mime];
}

// VLM의 연속 반복 정리
function cleanRepetition($text)
{
    $parts = preg_split('/(?<=[.!?。！？])\s+|\R+/u', $text, -1, PREG_SPLIT_NO_EMPTY | PREG_SPLIT_OFFSET_CAPTURE);
    if ($parts === false) return $text;
    $keys = array_map(function ($part) { return preg_replace('/\s+/u', ' ', trim($part[0])); }, $parts);
    $clean = '';
    $cursor = 0;
    $count = count($parts);
    for ($i = 0; $i < $count; $i++) {
        if (!preg_match('/^.{12,}$/us', $keys[$i])) continue;
        $end = $i + 1;
        while ($end < $count && $keys[$end] === $keys[$i]) $end++;
        if ($end - $i < 3) continue;
        $keepEnd = $parts[$i][1] + strlen($parts[$i][0]);
        if ($end === $count - 1 && preg_match('/^.{8,}$/us', $keys[$end]) && strpos($keys[$i], $keys[$end]) === 0) $end++;
        $clean .= substr($text, $cursor, $keepEnd - $cursor);
        $cursor = $parts[$end - 1][1] + strlen($parts[$end - 1][0]);
        $i = $end - 1;
    }
    return $cursor ? rtrim($clean . substr($text, $cursor)) : $text;
}

// 입력 처리
if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
    header('Allow: POST');
    fail('HTML 화면에서 POST로 호출해 주세요.', 405);
}
if (($_SERVER['HTTP_SEC_FETCH_SITE'] ?? '') === 'cross-site') fail('HTML과 PHP를 같은 서버에서 실행해 주세요.', 403);
if ((int) ($_SERVER['CONTENT_LENGTH'] ?? 0) > 2228224) fail('요청 크기를 줄여 주세요.', 413);
if (!$_POST && !$_FILES) fail('입력이 비어 있습니다. PHP 업로드 제한과 요청 형식을 확인해 주세요.');

$action = field('action', 'run');
if ($action === 'agree-license') {
    if (field('license_consent') !== '1') fail('이용 정책에 동의한 경우에만 요청해 주세요.');
    cloudflare($models['image-analysis'][0], ['prompt' => 'agree']);
    respond(['ok' => true, 'message' => '동의 요청이 완료되었습니다. 이미지 분석을 실행해 주세요.']);
}
if ($action !== 'run') fail('지원하지 않는 요청입니다.');
$task = field('taskType', 'text-generation');
$model = field('model', $models['text-generation'][0]);
if (!isset($models[$task]) || !in_array($model, $models[$task], true)) fail('작업에 맞는 모델을 선택해 주세요.');
$prompt = field('prompt');
if (strlen($prompt) > 12000) fail('프롬프트를 12KB 이하로 줄여 주세요.');
if (($task === 'text-generation' || $task === 'text-to-image' || $task === 'text-classification') && $prompt === '') fail('프롬프트를 입력해 주세요.');
if ($task === 'text-generation' || $task === 'image-analysis') {
    $tokens = filter_var(field('max_tokens', $task === 'image-analysis' ? '256' : '512'), FILTER_VALIDATE_INT);
    if ($tokens === false || $tokens < 64 || $tokens > 2048) fail('출력 토큰은 64~2048의 정수여야 합니다.');
}

// 작업별 요청
$mime = 'application/json';
switch ($task) {
    case 'text-classification': 
        $payload = ['text' => $prompt]; 
        break;

    case 'text-generation':
        $payload = ['messages' => [['role' => 'user', 'content' => $prompt]], 'max_tokens' => $tokens, 'stream' => false];
        break;
    case 'image-analysis':
        $image = uploadedImage();
        $instructions = 'Answer the image question in Korean using only visible evidence. '
            . 'Do not invent names or facts. If uncertain, say so. Do not repeat sentences or phrases. '
            . 'Use 2-4 sentences unless the user asks for more detail or transcription. Stop when the answer is complete.';
        $payload = [
            'prompt' => $instructions . "\n\nUser request:\n" . ($prompt === '' ? 'Describe the main subject and visible details.' : $prompt),
            'image' => 'data:' . $image['mime'] . ';base64,' . base64_encode($image['bytes']),
            'max_tokens' => $tokens, 'stream' => false,
            'temperature' => 0.2, 'top_p' => 0.9,
            'repetition_penalty' => 1.15, 'frequency_penalty' => 0.4
        ];
        break;
    case 'image-classification':
        $image = uploadedImage();
        $payload = $image['bytes'];
        $mime = $image['mime'];
        break;
    case 'text-to-image':
        $chars = preg_match_all('/./us', $prompt, $matches);
        if ($chars === false || $chars > 2048) fail('이미지 생성 프롬프트는 2048자 이하여야 합니다.');
        $steps = filter_var(field('steps', '4'), FILTER_VALIDATE_INT);
        if ($steps === false || $steps < 1 || $steps > 8) fail('생성 단계는 1~8의 정수여야 합니다.');
        $payload = ['prompt' => $prompt, 'steps' => $steps];
        break;
}
$result = cloudflare($model, $payload, $mime);

// 결과 반환
if ($task === 'text-generation' || $task === 'image-analysis') {
    $text = is_string($result) ? $result : ($result['response'] ?? ($result['choices'][0]['message']['content'] ?? ''));
    if (!is_string($text) || trim($text) === '') fail('모델 응답이 비어 있습니다.', 502);
    $clean = $task === 'image-analysis' ? cleanRepetition($text) : $text;
    respond(['ok' => true, 'kind' => 'text', 'result' => $clean, 'repetition_removed' => $clean !== $text,
        'message' => $clean !== $text ? '연속 반복 문장을 정리했습니다. 원문은 JSON 응답의 raw_response에서 확인하세요.' : '완료']);
}
if ($task === 'image-classification' || $task === 'text-classification') {
    if (!is_array($result)) fail('이미지 분류 결과가 잘못되었습니다.', 502);
    $predictions = [];
    foreach ($result as $row) {
        if (is_array($row) && isset($row['label'], $row['score']) && is_string($row['label']) && is_numeric($row['score'])) {
            $predictions[] = ['label' => $row['label'], 'score' => (float) $row['score']];
        }
    }
    if (!$predictions) fail('이미지 분류 결과가 비어 있습니다.', 502);
    usort($predictions, function ($a, $b) { return $b['score'] <=> $a['score']; });
    respond(['ok' => true, 'kind' => 'classification', 'predictions' => array_slice($predictions, 0, 10)]);
}
$base64 = $result['image'] ?? '';
if (!is_string($base64) || strlen($base64) > 20000000) fail('이미지 응답 형식이 잘못되었습니다.', 502);
$bytes = base64_decode($base64, true);
$info = $bytes !== false ? @getimagesizefromstring($bytes) : false;
$mime = $info['mime'] ?? '';
if (!in_array($mime, ['image/png', 'image/jpeg', 'image/webp'], true)) fail('생성 이미지를 읽지 못했습니다.', 502);
respond(['ok' => true, 'kind' => 'image', 'image' => ['data_uri' => 'data:' . $mime . ';base64,' . base64_encode($bytes)]]);
?>
