#include "userprog/process.h"
#include <debug.h>
#include <inttypes.h>
#include <round.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "userprog/gdt.h"
#include "userprog/pagedir.h"
#include "userprog/tss.h"
#include "filesys/directory.h"
#include "filesys/file.h"
#include "filesys/filesys.h"
#include "threads/flags.h"
#include "threads/init.h"
#include "threads/interrupt.h"
#include "threads/palloc.h"
#include "threads/thread.h"
#include "threads/vaddr.h"
#include "threads/malloc.h"
#include "userprog/syscall.h"

static thread_func start_process NO_RETURN;
static bool load (const char *cmdline, void (**eip) (void), void **esp);
static void argument_stack (char **argv, int argc, void **esp);

/* Starts a new thread running a user program loaded from
   FILENAME.  The new thread may be scheduled (and may even exit)
   before process_execute() returns.  Returns the new process's
   thread id, or TID_ERROR if the thread cannot be created. */
tid_t
process_execute (const char *file_name) 
{
  char *fn_copy;
  tid_t tid;

  /* Make a copy of FILE_NAME.
     Otherwise there's a race between the caller and load(). */
  fn_copy = palloc_get_page (0);
  if (fn_copy == NULL)
    return TID_ERROR;
  strlcpy (fn_copy, file_name, PGSIZE);

  // 프로그램 이름만 추출 (예: "echo x" -> "echo")
  char prog_name[64];         // 프로그램 이름 담을 빈 배열
  char *save_ptr;             // strtok_r에서 쓸 포인터
  strlcpy (prog_name, file_name, sizeof prog_name);       // file_name을 prog_name에 그대로 복사
  char *real_name = strtok_r (prog_name, " ", &save_ptr); // 공백 단위로 분리하여 프로그램 이름만 추출

  /* Create a new thread to execute FILE_NAME. */
  tid = thread_create (real_name, PRI_DEFAULT, start_process, fn_copy);
  if (tid == TID_ERROR) {
    palloc_free_page (fn_copy); 
    return TID_ERROR;
  }

  // 시스템콜 여기 구현 - 자식 상태 객체 생성 및 리스트 삽입, 자식 로딩 완료 대기
  struct child_status *child = malloc (sizeof (struct child_status));
  if (child == NULL)
    return TID_ERROR;
    
  child->tid = tid;
  child->exit_status = -1;
  child->is_exit = false;
  child->is_waiting = false;
  sema_init (&child->wait_sema, 0);
  list_push_back (&thread_current ()->child_list, &child->elem);

  sema_down (&thread_current ()->load_sema);
  if (!thread_current ()->load_success)
    return TID_ERROR;

  return tid;
}

/* A thread function that loads a user process and starts it
   running. */
static void
start_process (void *file_name_)
{
  char *file_name = file_name_;
  struct intr_frame if_;
  bool success;

  /* Initialize interrupt frame and load executable. */
  memset (&if_, 0, sizeof if_);
  if_.gs = if_.fs = if_.es = if_.ds = if_.ss = SEL_UDSEG;
  if_.cs = SEL_UCSEG;
  if_.eflags = FLAG_IF | FLAG_MBS;
  success = load (file_name, &if_.eip, &if_.esp);

  // 시스템콜 여기 구현 - 자식 로드 완료 상태를 부모에게 기록하고, 대기 중인 부모를 깨움
  thread_current ()->parent->load_success = success;
  sema_up (&thread_current ()->parent->load_sema);

  /* If load failed, quit. */
  palloc_free_page (file_name);
  if (!success) 
    thread_exit ();

  /* Start the user process by simulating a return from an
     interrupt, implemented by intr_exit (in
     threads/intr-stubs.S).  Because intr_exit takes all of its
     arguments on the stack in the form of a `struct intr_frame',
     we just point the stack pointer (%esp) to our stack frame
     and jump to it. */
  asm volatile ("movl %0, %%esp; jmp intr_exit" : : "g" (&if_) : "memory");
  NOT_REACHED ();
}

/* Waits for thread TID to die and returns its exit status.  If
   it was terminated by the kernel (i.e. killed due to an
   exception), returns -1.  If TID is invalid or if it was not a
   child of the calling process, or if process_wait() has already
   been successfully called for the given TID, returns -1
   immediately, without waiting.

   This function will be implemented in problem 2-2.  For now, it
   does nothing. */
int
process_wait (tid_t child_tid) 
{
  // 시스템콜 여기 구현 - 자식 리스트를 탐색하여 해당 자식이 종료될 때까지 대기 후 상태 회수
  struct list *child_list = &thread_current ()->child_list;
  struct list_elem *e;
  struct child_status *child = NULL;
  int status = -1;

  for (e = list_begin (child_list); e != list_end (child_list); e = list_next (e))
    {
      struct child_status *c = list_entry (e, struct child_status, elem);
      if (c->tid == child_tid)
        {
          child = c;
          break;
        }
    }

  if (child == NULL)
    return -1;
  if (child->is_waiting)
    return -1;

  child->is_waiting = true;

  if (!child->is_exit)
    sema_down (&child->wait_sema);

  status = child->exit_status;
  list_remove (&child->elem);
  free (child);

  return status;
}

/* Free the current process's resources. */
void
process_exit (void)
{
  struct thread *cur = thread_current ();
  uint32_t *pd;
  
  // 시스템콜 여기 구현 - 부모의 자식 리스트에 내 종료 상태를 업데이트하고, 남은 자식들 메모리 해제
  struct list_elem *e;
  if (cur->parent != NULL) 
    {
      for (e = list_begin (&cur->parent->child_list); e != list_end (&cur->parent->child_list); e = list_next (e))
        {
          struct child_status *child = list_entry (e, struct child_status, elem);
          if (child->tid == cur->tid)
            {
              child->is_exit = true;
              child->exit_status = cur->exit_status;
              sema_up (&child->wait_sema);
              break;
            }
        }
    }
    
  // 자식 프로세스 리스트 메모리 해제
  while (!list_empty (&cur->child_list))
    {
      struct list_elem *e = list_pop_front (&cur->child_list);
      struct child_status *child = list_entry (e, struct child_status, elem);
      free (child);
    }

  // 3. 여기를 수정해야함
  // 프로세스가 열어둔 모든 파일 디스크립터의 파일을 닫아 자원 회수
  lock_acquire (&filesys_lock);
  
  int i;
  for (i = 2; i < 128; i++)
    {
      if (cur->fd_table[i] != NULL)
        {
          file_close (cur->fd_table[i]);
          cur->fd_table[i] = NULL;
        }
    }

  // synchronization 여기 구현 - 실행 중이던 파일 닫아주기 (쓰기 권한 반환)
  if (cur->run_file != NULL)
    {
      file_close (cur->run_file);
    }
    
  lock_release (&filesys_lock);

  /* Destroy the current process's page directory and switch back
     to the kernel-only page directory. */
  pd = cur->pagedir;
  if (pd != NULL) 
    {
      /* Correct ordering here is crucial.  We must set
         cur->pagedir to NULL before switching page directories,
         so that a timer interrupt can't switch back to the
         process page directory.  We must activate the base page
         directory before destroying the process's page
         directory, or our active page directory will be one
         that's been freed (and cleared). */
      cur->pagedir = NULL;
      pagedir_activate (NULL);
      pagedir_destroy (pd);
    }
}

/* Sets up the CPU for running user code in the current
   thread.
   This function is called on every context switch. */
void
process_activate (void)
{
  struct thread *t = thread_current ();

  /* Activate thread's page tables. */
  pagedir_activate (t->pagedir);

  /* Set thread's kernel stack for use in processing
     interrupts. */
  tss_update ();
}

/* We load ELF binaries.  The following definitions are taken
   from the ELF specification, [ELF1], more-or-less verbatim.  */

/* ELF types.  See [ELF1] 1-2. */
typedef uint32_t Elf32_Word, Elf32_Addr, Elf32_Off;
typedef uint16_t Elf32_Half;

/* For use with ELF types in printf(). */
#define PE32Wx PRIx32   /* Print Elf32_Word in hexadecimal. */
#define PE32Ax PRIx32   /* Print Elf32_Addr in hexadecimal. */
#define PE32Ox PRIx32   /* Print Elf32_Off in hexadecimal. */
#define PE32Hx PRIx16   /* Print Elf32_Half in hexadecimal. */

/* Executable header.  See [ELF1] 1-4 to 1-8.
   This appears at the very beginning of an ELF binary. */
struct Elf32_Ehdr
  {
    unsigned char e_ident[16];
    Elf32_Half    e_type;
    Elf32_Half    e_machine;
    Elf32_Word    e_version;
    Elf32_Addr    e_entry;
    Elf32_Off     e_phoff;
    Elf32_Off     e_shoff;
    Elf32_Word    e_flags;
    Elf32_Half    e_ehsize;
    Elf32_Half    e_phentsize;
    Elf32_Half    e_phnum;
    Elf32_Half    e_shentsize;
    Elf32_Half    e_shnum;
    Elf32_Half    e_shstrndx;
  };

/* Program header.  See [ELF1] 2-2 to 2-4.
   There are e_phnum of these, starting at file offset e_phoff
   (see [ELF1] 1-6). */
struct Elf32_Phdr
  {
    Elf32_Word p_type;
    Elf32_Off  p_offset;
    Elf32_Addr p_vaddr;
    Elf32_Addr p_paddr;
    Elf32_Word p_filesz;
    Elf32_Word p_memsz;
    Elf32_Word p_flags;
    Elf32_Word p_align;
  };

/* Values for p_type.  See [ELF1] 2-3. */
#define PT_NULL    0            /* Ignore. */
#define PT_LOAD    1            /* Loadable segment. */
#define PT_DYNAMIC 2            /* Dynamic linking info. */
#define PT_INTERP  3            /* Name of dynamic loader. */
#define PT_NOTE    4            /* Auxiliary info. */
#define PT_SHLIB   5            /* Reserved. */
#define PT_PHDR    6            /* Program header table. */
#define PT_STACK   0x6474e551   /* Stack segment. */

/* Flags for p_flags.  See [ELF3] 2-3 and 2-4. */
#define PF_X 1          /* Executable. */
#define PF_W 2          /* Writable. */
#define PF_R 4          /* Readable. */

static bool setup_stack (void **esp);
static bool validate_segment (const struct Elf32_Phdr *, struct file *);
static bool load_segment (struct file *file, off_t ofs, uint8_t *upage,
                          uint32_t read_bytes, uint32_t zero_bytes,
                          bool writable);

/* Loads an ELF executable from FILE_NAME into the current thread.
   Stores the executable's entry point into *EIP
   and its initial stack pointer into *ESP.
   Returns true if successful, false otherwise. */
bool
load (const char *file_name, void (**eip) (void), void **esp) 
{
  struct thread *t = thread_current ();
  struct Elf32_Ehdr ehdr;
  struct file *file = NULL;
  off_t file_ofs;
  bool success = false;
  int i;

  // [Issue 2 해결] 실행 파일 로드 시 발생하는 파일 시스템 동시성 문제 방지를 위해 락 획득
  lock_acquire (&filesys_lock);

  /* Allocate and activate page directory. */
  t->pagedir = pagedir_create (); // 이 부분은 문제 없음. thread.h 확인해보면 ifdef으로 정의되어 있음.
  if (t->pagedir == NULL) 
    goto done;
  process_activate ();



  // ★ 여기서 parsing을 해야함
  char *argv[128];        // 분리한 명령어들의 주소 하나씩 담을 배열
  int argc = 0;           // 분리한 명령어들의 개수
  char *token, *save_ptr; // strtok에서 쓸 포인터

  // 공백 단위로 분리하기
  for (token = strtok_r ((char *) file_name, " ", &save_ptr); token != NULL;
       token = strtok_r (NULL, " ", &save_ptr))
    {
      argv[argc++] = token;
    }


    
  /* Open executable file. */
  file = filesys_open (argv[0]);    // argv[0]을 넘기기 -> echo 넘기기
  if (file == NULL) 
    {
      printf ("load: %s: open failed\n", argv[0]);
      goto done; 
    }

  /* Read and verify executable header. */
  if (file_read (file, &ehdr, sizeof ehdr) != sizeof ehdr
      || memcmp (ehdr.e_ident, "\177ELF\1\1\1", 7)
      || ehdr.e_type != 2
      || ehdr.e_machine != 3
      || ehdr.e_version != 1
      || ehdr.e_phentsize != sizeof (struct Elf32_Phdr)
      || ehdr.e_phnum > 1024) 
    {
      printf ("load: %s: error loading executable\n", file_name);
      goto done; 
    }

  /* Read program headers. */
  file_ofs = ehdr.e_phoff;
  for (i = 0; i < ehdr.e_phnum; i++) 
    {
      struct Elf32_Phdr phdr;

      if (file_ofs < 0 || file_ofs > file_length (file))
        goto done;
      file_seek (file, file_ofs);

      if (file_read (file, &phdr, sizeof phdr) != sizeof phdr)
        goto done;
      file_ofs += sizeof phdr;
      switch (phdr.p_type) 
        {
        case PT_NULL:
        case PT_NOTE:
        case PT_PHDR:
        case PT_STACK:
        default:
          /* Ignore this segment. */
          break;
        case PT_DYNAMIC:
        case PT_INTERP:
        case PT_SHLIB:
          goto done;
        case PT_LOAD:
          if (validate_segment (&phdr, file)) 
            {
              bool writable = (phdr.p_flags & PF_W) != 0;
              uint32_t file_page = phdr.p_offset & ~PGMASK;
              uint32_t mem_page = phdr.p_vaddr & ~PGMASK;
              uint32_t page_offset = phdr.p_vaddr & PGMASK;
              uint32_t read_bytes, zero_bytes;
              if (phdr.p_filesz > 0)
                {
                  /* Normal segment.
                     Read initial part from disk and zero the rest. */
                  read_bytes = page_offset + phdr.p_filesz;
                  zero_bytes = (ROUND_UP (page_offset + phdr.p_memsz, PGSIZE)
                                - read_bytes);
                }
              else 
                {
                  /* Entirely zero.
                     Don't read anything from disk. */
                  read_bytes = 0;
                  zero_bytes = ROUND_UP (page_offset + phdr.p_memsz, PGSIZE);
                }
              if (!load_segment (file, file_page, (void *) mem_page,
                                 read_bytes, zero_bytes, writable))
                goto done;
            }
          else
            goto done;
          break;
        }
    }

  
  
  /* Set up stack. */
  if (!setup_stack (esp))
    goto done;


  
  // ★ 여기를 수정해야한다! -> 여기서 유저 스택에 echo, x 하나씩 넣어줘야함.
  // 인자들을 유저 스택에 넣어주기.
  argument_stack (argv, argc, esp);

  // 디버깅용: 스택 메모리 덤프 출력 (과제 완료 후 주석 처리 가능)
  // hex_dump ((uintptr_t) *esp, *esp, PHYS_BASE - *esp, true);



  /* Start address. */
  *eip = (void (*) (void)) ehdr.e_entry;

  success = true;

 done:
  /* We arrive here whether the load is successful or not. */
  if (success) 
    {
      // synchronization 여기 구현 - 성공적으로 로드된 경우 파일을 닫지 않고 쓰기 방지 설정
      thread_current ()->run_file = file;
      file_deny_write (file);
    }
  else 
    {
      file_close (file);
    }
    
  // [Issue 2 해결] 파일 시스템 동기화 락 해제
  lock_release (&filesys_lock);
  return success;
}

/* load() helpers. */

// 80x86 호출 규약에 따라 파싱된 인자들을 유저 스택에 푸시
static void
argument_stack (char **argv, int argc, void **esp)
{
  int i;
  uint32_t argv_addr[128];

  // 1. 문자열 인자들을 스택에 역순으로 푸시 (echo x 면 x -> echo 순으로)
  for (i = argc - 1; i >= 0; i--)
    {
      size_t len = strlen (argv[i]) + 1; // '\0' 널 종료 문자 포함
      *esp -= len;
      memcpy (*esp, argv[i], len);
      argv_addr[i] = (uint32_t) *esp;   // 스택에 저장된 해당 인자의 시작 주소 기억 (나중에 이거도 푸시해야함)
    }

  // 2. 워드 정렬 (4바이트 단위 정렬)
  int align = (uintptr_t) *esp % 4;
  if (align != 0)
    {
      *esp -= align;
      memset (*esp, 0, align);
    }

  // 3. argv[argc] = NULL 푸시
  *esp -= 4;
  *(uint32_t *) *esp = 0;

  // 4. 각 문자열 인자들의 시작 주소를 역순으로 푸시
  for (i = argc - 1; i >= 0; i--)
    {
      *esp -= 4;
      *(uint32_t *) *esp = argv_addr[i];
    }

  // 5. argv의 주소 (argv[0]의 주소가 들어있는 스택 주소) 푸시
  uint32_t argv_start = (uint32_t) *esp;
  *esp -= 4;
  *(uint32_t *) *esp = argv_start;

  // 6. argc (인자 개수) 푸시
  *esp -= 4;
  *(int *) *esp = argc;

  // 7. 가짜 반환 주소 (Fake return address: 0) 푸시
  *esp -= 4;
  *(uint32_t *) *esp = 0;
}

static bool install_page (void *upage, void *kpage, bool writable);

/* Checks whether PHDR describes a valid, loadable segment in
   FILE and returns true if so, false otherwise. */
static bool
validate_segment (const struct Elf32_Phdr *phdr, struct file *file) 
{
  /* p_offset and p_vaddr must have the same page offset. */
  if ((phdr->p_offset & PGMASK) != (phdr->p_vaddr & PGMASK)) 
    return false; 

  /* p_offset must point within FILE. */
  if (phdr->p_offset > (Elf32_Off) file_length (file)) 
    return false;

  /* p_memsz must be at least as big as p_filesz. */
  if (phdr->p_memsz < phdr->p_filesz) 
    return false; 

  /* The segment must not be empty. */
  if (phdr->p_memsz == 0)
    return false;
  
  /* The virtual memory region must both start and end within the
     user address space range. */
  if (!is_user_vaddr ((void *) phdr->p_vaddr))
    return false;
  if (!is_user_vaddr ((void *) (phdr->p_vaddr + phdr->p_memsz)))
    return false;

  /* The region cannot "wrap around" across the kernel virtual
     address space. */
  if (phdr->p_vaddr + phdr->p_memsz < phdr->p_vaddr)
    return false;

  /* Disallow mapping page 0.
     Not only is it a bad idea to map page 0, but if we allowed
     it then user code that passed a null pointer to system calls
     could quite likely panic the kernel by way of null pointer
     assertions in memcpy(), etc. */
  if (phdr->p_vaddr < PGSIZE)
    return false;

  /* It's okay. */
  return true;
}

/* Loads a segment starting at offset OFS in FILE at address
   UPAGE.  In total, READ_BYTES + ZERO_BYTES bytes of virtual
   memory are initialized, as follows:

        - READ_BYTES bytes at UPAGE must be read from FILE
          starting at offset OFS.

        - ZERO_BYTES bytes at UPAGE + READ_BYTES must be zeroed.

   The pages initialized by this function must be writable by the
   user process if WRITABLE is true, read-only otherwise.

   Return true if successful, false if a memory allocation error
   or disk read error occurs. */
static bool
load_segment (struct file *file, off_t ofs, uint8_t *upage,
              uint32_t read_bytes, uint32_t zero_bytes, bool writable) 
{
  ASSERT ((read_bytes + zero_bytes) % PGSIZE == 0);
  ASSERT (pg_ofs (upage) == 0);
  ASSERT (ofs % PGSIZE == 0);

  file_seek (file, ofs);
  while (read_bytes > 0 || zero_bytes > 0) 
    {
      /* Calculate how to fill this page.
         We will read PAGE_READ_BYTES bytes from FILE
         and zero the final PAGE_ZERO_BYTES bytes. */
      size_t page_read_bytes = read_bytes < PGSIZE ? read_bytes : PGSIZE;
      size_t page_zero_bytes = PGSIZE - page_read_bytes;

      /* Get a page of memory. */
      uint8_t *kpage = palloc_get_page (PAL_USER);
      if (kpage == NULL)
        return false;

      /* Load this page. */
      if (file_read (file, kpage, page_read_bytes) != (int) page_read_bytes)
        {
          palloc_free_page (kpage);
          return false; 
        }
      memset (kpage + page_read_bytes, 0, page_zero_bytes);

      /* Add the page to the process's address space. */
      if (!install_page (upage, kpage, writable)) 
        {
          palloc_free_page (kpage);
          return false; 
        }

      /* Advance. */
      read_bytes -= page_read_bytes;
      zero_bytes -= page_zero_bytes;
      upage += PGSIZE;
    }
  return true;
}

/* Create a minimal stack by mapping a zeroed page at the top of
   user virtual memory. */
static bool
setup_stack (void **esp) 
{
  uint8_t *kpage;
  bool success = false;

  kpage = palloc_get_page (PAL_USER | PAL_ZERO);
  if (kpage != NULL) 
    {
      success = install_page (((uint8_t *) PHYS_BASE) - PGSIZE, kpage, true);
      if (success)
        *esp = PHYS_BASE;
      else
        palloc_free_page (kpage);
    }
  return success;
}

/* Adds a mapping from user virtual address UPAGE to kernel
   virtual address KPAGE to the page table.
   If WRITABLE is true, the user process may modify the page;
   otherwise, it is read-only.
   UPAGE must not already be mapped.
   KPAGE should probably be a page obtained from the user pool
   with palloc_get_page().
   Returns true on success, false if UPAGE is already mapped or
   if memory allocation fails. */
static bool
install_page (void *upage, void *kpage, bool writable)
{
  struct thread *t = thread_current ();

  /* Verify that there's not already a page at that virtual
     address, then map our page there. */
  return (pagedir_get_page (t->pagedir, upage) == NULL
          && pagedir_set_page (t->pagedir, upage, kpage, writable));
}
